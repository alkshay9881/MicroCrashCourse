package com.service.registry.service_registry_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceRegistryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
