package com.service.registry.service_registry_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceRegistryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceRegistryAppApplication.class, args);
	}

}
